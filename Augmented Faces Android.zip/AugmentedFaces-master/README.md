# AugmentedFaces
A basic app which overlay a custom model and Texture to your face.
<br>
[!["Buy Me A Coffee"](https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png)](https://www.buymeacoffee.com/raghavtilak)
